#!/bin/bash
yui-compressor jquery.checkboxtree.js -o jquery.checkboxtree.min.js
yui-compressor jquery.checkboxtree.css -o jquery.checkboxtree.min.css
